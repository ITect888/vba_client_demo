package com.ect888.picscale;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PicScaleApplication {

	public static void main(String[] args) {
		SpringApplication.run(PicScaleApplication.class, args);
	}

}
